package com.dac.problem2;

import java.util.Scanner;

/*
 * Create a class Circle that has two data members, 
 * one to store the radius and another to store area and
 *  three methods first init() method to input radius from user,
 *   second calculateArea() method to calculate area of circle
 *    and third display() method to display values of radius and area.
 *     Create class CircleDemo ( main class) that
 *      creates the Circle object and calls init(), calculateArea()
 *       and display() methods
 * 
 */

class Circle {
	float radious;
	double area;
	void init()
	{
		Scanner sc=new Scanner(System.in);
		int rr=sc.nextInt();
		radious=rr;
	}
	void calculateArea()
		{
		double area1=(3.14*radious*radious);
		this.area=area1;
		}
	void display()
	{
		System.out.println("Radius  of Circle :"+radious);
		System.out.println("Area of Circle :"+area);
	}
}
public class CircleDemo {

	public static void main(String[] args) {
		Circle c=new Circle();
			c.init();
			c.calculateArea();
			c.display();
	}

}
