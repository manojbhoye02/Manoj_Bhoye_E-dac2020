package com.dac.problem6;

import java.util.*;

class Product
{
    int pid;
    float price;
    int quantity;
    Product(int p, float pr, int qu)
    {
       pid=p;
       price=pr;
       quantity=qu;
    }
    static double cal(Product p[])
    {
        double totalamnt=0;
        for(int i=0;i<p.length;i++)
        {
          totalamnt=totalamnt + (p[i].price*p[i].quantity);
        }
        return totalamnt;
    }
}
class ProductDemo
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        //a
        Product p[]=new Product[5];
        for(int i=0; i<p.length;i++)
        {
            System.out.println("Enter id, price and quantity of Product : ");
            int id=sc.nextInt();
            float pr=sc.nextFloat();
            int q=sc.nextInt();
            p[i]=new Product(id,pr,q);
        }
        //b
        float max=0;
        int pid=0;
        for(int i=0; i<p.length;i++)
        {
            if(p[i].price>max)
            {
              max=p[i].price;
              pid=p[i].pid;
            }
        }
        System.out.println("Pid of Product with highest price : "+pid);
       //c 
        System.out.println("Total Amount Spend on all products : "+Product.cal(p));
    }
}