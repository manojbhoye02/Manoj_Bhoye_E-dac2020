package com.dac.problem4;

import java.awt.geom.Area;
import java.util.Scanner;

/*Create a class MathOperation containing overloaded methods
 *  �multiply� to calculate multiplication of following arguments. 
 	two integers 
 	three floats 
 	all elements of array 
	one double and one integer
 */
public class MathOperation {
	public void multiply(int num1,int num2)
	{
		int mul1=num1*num2;
		System.out.println("Multiplication of 1 :"+mul1);
	}
	public void multiply(float num1,float num2,float num3)
	{
		double mul2=num1*num2*num3;
		System.out.println("Multiplication of 2 :"+mul2);
	}
	public void multiply(int myarr[])
	{ 	int mul=1;
		for(int i = 0; i<myarr.length; i++ )
	{
		mul=mul*myarr[i];
	}		
		System.out.println("Multiplication of 1 :"+mul);
	}
	
	public void multiply(double num1,int num2)
	{
		double mul4=num1*num2;
		System.out.println("Multiplication of 4 :"+mul4);
	}

	public static void main(String[] args) {
		MathOperation m=new MathOperation();
		Scanner sc=new Scanner(System.in);
		
		m.multiply(sc.nextInt(), sc.nextInt());
		m.multiply(sc.nextFloat(), sc.nextFloat(), sc.nextFloat());
		
		 int size = sc.nextInt();
	      int[] myArray = new int[size];
	      System.out.println("Enter the elements of the array ::");

	      for(int i=0; i<size; i++) {
	         myArray[i] = sc.nextInt();
	      }		
	      	m.multiply(myArray);
		
		m.multiply(sc.nextDouble(), sc.nextInt());

	}

}
