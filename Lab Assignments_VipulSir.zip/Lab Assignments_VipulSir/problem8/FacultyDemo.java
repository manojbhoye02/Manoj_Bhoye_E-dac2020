package com.dac.problem8;

import java.util.*;

class Faculty
{
    int facultyId;
    double salary;
    void intput(int id)
    {
        facultyId=id;       
    }
    void printSalary()
    {
        System.out.println("Salary of Employee: "+salary);
    }
}
class FulltimeFaculty extends Faculty
{
    double basicSalary;
    double allowance;
    void intput(int id,double bs,double aw)
    {
        super.intput(id);
        basicSalary=bs;
        allowance=aw;
        super.salary=basicSalary + allowance;
    }
}
class ParttimeFaculty extends Faculty
{
    int workingHours;
    int ratePerHour;
    void intput(int id,int wh,int rh)
    {
        super.intput(id);
        workingHours=wh;
        ratePerHour=rh;
        super.salary=workingHours * ratePerHour;
    }
}
class FacultyDemo
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Type Of Employee (FullTime=F or PartTime=P)");
        char c=sc.next().charAt(0); 
        int id;
        switch(c)
        {
            case 'F':FulltimeFaculty f=new FulltimeFaculty();
           System.out.println("Enter Employee Id,basic salary & allowance for Full time Employee");
           id=sc.nextInt();
           double bs=sc.nextDouble();
           double aw=sc.nextDouble();           
           f.intput(id,bs,aw);
           f.printSalary();
           break;
           
           case 'P':ParttimeFaculty p=new ParttimeFaculty();
           System.out.println("Enter Employee Id,Working Hours & rate per Hour for Part time Employee");
           id=sc.nextInt();
           int wh=sc.nextInt();
           int rh=sc.nextInt();           
           p.intput(id,wh,rh);
           p.printSalary();
           break;
           
           default:
                System.out.println("Enter valid choice");
        }
    }
}