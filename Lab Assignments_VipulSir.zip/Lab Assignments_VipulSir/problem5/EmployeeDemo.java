package com.dac.problem5;

import java.util.Scanner;

/*Create a class Employee with three data members
 *  (empNo, salary and totalSalary) and following features.
	Only parameterized constructor. [Do not overload the constructor]
	totalSalary always represents salary total of all the employees
	 created.
	empNo should be auto incremented.
	display total employees and totalSalary using a method.
	Create another class EmployeeDemo (main class) that 
	creates some Employee objects and calls Employee method 
	to display no. of employees and total of their salaries.
 */
 class Employee {
	static int empNo=0;
	double salary;
	static  double totalsalary=0;
	
	public Employee(double s) {
		
		this.salary=s;
		empNo++;
		totalsalary=totalsalary+salary;
	}
	
	public void display()
	{
		System.out.println("total Employee  :"+empNo);
		System.out.println("Employee total salary :"+totalsalary);
	}
 }
	public class EmployeeDemo{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Employee e1=new Employee(sc.nextDouble());
		e1.display();
		Employee e2=new Employee(sc.nextDouble());
		e2.display();
		Employee e3=new Employee(sc.nextDouble());
		e3.display();
		Employee e4=new Employee(sc.nextDouble());
		e4.display();
		Employee e5=new Employee(sc.nextDouble());
		e5.display();

	}
	}

