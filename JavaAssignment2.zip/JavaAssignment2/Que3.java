package JavaAssignment2;

import java.util.Scanner;

class Que3{
public static void main (String args[])
    {
        int a,j,flag;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the no");
        a=sc.nextInt();
        flag=1;
            for(j=2;j<=a/2;j++)
            {
                if(a%j==0){
                    flag=0;
                    break;
                }
            }
            if(flag == 1)
                System.out.println(a+"is prime");
            else
                System.out.println("not prime");
            
}

}