package Assignment1;

class Q3 
{
    public static void main (String args[])
           {
               int x=10;
               int y=5;
               int z;
               
               y= x*x + 3*x-7;
               System.out.println("x="+x+" y="+y);
               
               y = x++ + ++x;
               
               System.out.println("x="+x+" y="+y);
               
               z= x++ - --y - --x + x++;
               
               System.out.println("x="+x+" y="+y+" z="+z);
               
               Q3 a=new Q3();
               a.val();
           }
    
    boolean val()
    {
        boolean x=true,y=true,z;
        z = (x && y)||!(x||y);
        System.out.println(z);
        return z;
    }
}