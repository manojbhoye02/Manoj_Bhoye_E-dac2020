package Assignment1;
import java.util.*;
class Q8
{
    public static void main(String args[])
    {
       float P, R, T, SI;
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter the Principal : ");
            P = scan.nextFloat();
            System.out.print("Enter the Rate of interest : ");
            R = scan.nextFloat();
            System.out.print("Enter the Time period : ");
            T = scan.nextFloat();
        
        SI = (P*R*T)/100;
        System.out.print("Simple Interest is: " +SI);
    }
}