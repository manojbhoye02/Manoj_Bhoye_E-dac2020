package Assignment1;

import java.util.*;

class Q7
{
    public static void main (String args[])
    {
     int sub1,sub2,sub3,sub4,sub5;
     float Sum, Percentage, Average;
		Scanner sc = new Scanner(System.in);
		
		System.out.print(" Please Enter the Five Subjects Marks : ");
		sub1 = sc.nextInt();	
		sub2 = sc.nextInt();	
		sub3 = sc.nextInt();	
		sub4 = sc.nextInt();	
		sub5 = sc.nextInt();	
		
		Sum = sub1+sub2+sub3+sub4+sub5;
		Average = Sum/5;
	    Percentage = (Sum/500)*100;
	    
	    System.out.println("Total sum = "+Sum);
	    System.out.println("Average = "+Average);
	    System.out.println("Percentage = "+Percentage);
     
    }
}