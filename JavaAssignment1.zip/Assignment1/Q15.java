package Assignment1;

import java.util.Scanner;

class Q15
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your age:");
        int age=sc.nextInt();
        System.out.println("enter your gender M or F ");
        char gender=sc.next().charAt(0);
        if (age>=18 && gender =='F')
        {
            System.out.println("Eligible for marriage");
        }
        else if (age>=21 && gender =='M')
        {
            System.out.println("Eligible for marriage");
        }
    }
}