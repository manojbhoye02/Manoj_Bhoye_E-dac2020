package Assignment1;

class Q4
{
    public static void main (String args[])
    {
        int a=10;
        int b=20;
        byte c=(byte) ((byte)a+b);
        System.out.println(c);
    }
}