package com.dac4;

public interface Exam 
{
		

	public abstract void examDetails();



}
