package com.dac4;

import java.util.Scanner;

import org.omg.CORBA.PUBLIC_MEMBER;

public class Student implements College,Exam {
			
	private int studentId;
	private String firstName;
	private String lastName;

	
	
	public Student(int id, String fn, String ln) {
		super();
		this.studentId = id;
		this.firstName = fn;
		this.lastName = ln;
	}


	@Override
	public void examDetails()
	{  
		
		int i;
		 double total = 0;
			 	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Subject");
		int n=sc.nextInt();
	
		int[] arr=new int[n];
		
		for( i=0;i<arr.length;i++)
		{
			System.out.println("Enter marks");
			arr[i]=sc.nextInt();
		}
		//sc.close();
		
		for( i=0;i<arr.length;i++)
		{
			total=total+arr[i];
			
		}
		double average=total/arr.length;
		
		System.out.println("Student average Mark :"+average);
		
		if(average>75)
		{
			System.out.println("Student Grade :First class");
		}
		else if (average>60)
		{
			System.out.println("Student Grade :Second Class");
		}
		else 
		{
			System.out.println("Student Grade :Failed..........");
		}
			
		
		
	
				}

	
	public static void main(String[] args) {
		Student s=new Student(11,"Manoj","Bhoye");
		System.out.println("Student ID :"+s.studentId);
		System.out.println("Student first name :"+s.firstName);
		System.out.println("Student sur name :"+s.lastName);
		System.out.println("Student College :"+College.college);
			s.examDetails();
	}


	
}
