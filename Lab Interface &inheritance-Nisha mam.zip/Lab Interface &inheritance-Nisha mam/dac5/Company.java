package com.dac5;

public interface Company {
	
	public static final String companyName="Credit Suisse";

}
