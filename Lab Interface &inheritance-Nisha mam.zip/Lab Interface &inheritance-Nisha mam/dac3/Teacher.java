package com.dac3;

public class Teacher extends Student implements School
{
	private int Teacherid;
	public String firstName;
		String Lastname;
		String subject;
		int age;

		
		
		
		
	public Teacher(int id, String fn, String ln, String sub, int a,int idd,String fnn,String lnn,int aa) {
			super(idd, fnn, lnn, aa);
			Teacherid = id;
			firstName = fn;
			Lastname = ln;
			subject = sub;
			age = a;
		}





	@Override
	public void StudentDetails() {
				
	}





	@Override
	public void TeacherDetails()
	{
		System.out.println("****************************");

		System.out.println("Teacher Id :"+Teacherid);
		System.out.println("Teacher Name :"+firstName);
		System.out.println("Teacher sur Name :"+Lastname);
		System.out.println("Subject tought :"+subject);
		System.out.println("Teacher Age :"+age);
		System.out.println("Teacher College :"+School.school);
		super.StudentDetails();
		System.out.println("****************************");
		
	}

	

}
