package com.dac1;

import java.util.Scanner;
public class Bankoperation {
	
	Customer a=new Customer();
	Scanner s2=new Scanner(System.in);
	
	public void createaccount()
	{
		System.out.println("Enter acoountno::");
       a.setAccountno(s2.nextLong());
       System.out.println("Enter name::");
       a.setName(s2.next());
       System.out.println("Enter Balance::");
       a.setBalance(s2.nextDouble());
       System.out.println(" Enter Dob::");
       a.setDob(s2.next());
       System.out.println( "Enter Emailid::");
       a.setEmailid(s2.next());
       System.out.println("Enter gender::");
       a.setGender(s2.next());
      }
	public void display()
	{
		System.out.println("Enter Account No  "+"   "+a.getAccountno());
		System.out.println("Enter Name        "+"   "+a.getName());
		System.out.println("Enter Balance     "+"   "+a.getBalance());
		System.out.println("enter Dob         "+"   "+a.getDob());
		System.out.println("Enter EmailId     "+"   "+a.getEmailid());
		System.out.println("enter Gender      "+"   "+a.getGender());
		
	}
	public void deposit(double balance){
		double pbal=a.getBalance();
		double newbal=pbal+balance;//previous balance
		a.setBalance(newbal);
		System.out.println("***********************************************************************************************************************************************************************************************");
		System.out.println("your current Balance"+"   "+a.getBalance());
		System.out.println("***********************************************************************************************************************************************************************************");
	}
	public void withdral(double balance){
		double pbal=a.getBalance();
		if(pbal>balance){
		double newbal=pbal-balance;
		a.setBalance(newbal);
		System.out.println("******************************************");
		System.out.println("your Current Balance"+"   "+a.getBalance());
		System.out.println("******************************************");
		System.out.println("\n");
		}
		else{
			System.out.println("-----------------------------------------");
			System.out.println("Transcation cancelled insufficient balance");
			System.out.println("-----------------------------------------");
			System.out.println("\n");
		}
		}
		public void checkedbalance()
		{
			double pbal=a.getBalance();
			System.out.println("-------------------------------------------");
			System.out.println("Your Current Bal "+"   "+pbal);
			System.out.println("-------------------------------------------");
			System.out.println("\n");
		}
		}
		
