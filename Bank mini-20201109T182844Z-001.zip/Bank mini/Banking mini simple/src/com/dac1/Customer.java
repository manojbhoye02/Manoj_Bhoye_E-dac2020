package com.dac1;

public class Customer {

	
		private long accountno;
		private String name;
		private String gender;
		private String dob;
		private String emailid;
		private	double balance;
		
		public long getAccountno() {
			return accountno;
		}
		public void setAccountno(long accountno) {
			this.accountno = accountno;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getEmailid() {
			return emailid;
		}
		public void setEmailid(String emailid) {
			this.emailid = emailid;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}

	}


